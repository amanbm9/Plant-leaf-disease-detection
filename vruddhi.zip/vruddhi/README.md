# Plant-Leaf-Disease-Detection
This is a computer vision matlab project that seeks to automatically detect and classify plant diseases of selected plants by analyzing the plants' leaves. This was implemented using a modified version of the Support Vector Machine as the classification model.
